SmartSprites: CSS Sprite Generator Done Right
---------------------------------------------

For a quick start, download SmartSprites binaries and run:

smartsprites --root-dir-path test/real-world-example

and look in test/real-world-example for the results.



For more instructions on using SmartSprites, please see:

http://csssprites.org

